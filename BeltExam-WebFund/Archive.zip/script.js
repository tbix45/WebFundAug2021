function changeimage() {
    document.querySelector('.blockaloe').setAttribute('src', 'images2/assets/succulents-2.jpg');
}
function changeback() {
    document.querySelector('.blockaloe').setAttribute('src', 'images2/assets/succulents-1.jpg');
}
// function accepted('alertbox') {
//     document.querySelector('alertbox');
//     alertbox.remove();
// }
function accepted() {
    document.querySelector('.alertbox').remove('.alertbox');
}