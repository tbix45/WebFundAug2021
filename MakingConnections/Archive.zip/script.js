function changename() {
    document.getElementById('myname').innerHTML = "Jane Doe";

}
// function removeuser() {
//     document.getElementsByClassName('bye').removeuser = ""
// }
